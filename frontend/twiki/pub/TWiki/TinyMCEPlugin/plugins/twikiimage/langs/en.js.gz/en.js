tinyMCE.addI18n('en.twikiimage', {
    image_desc: "Insert an image"
});