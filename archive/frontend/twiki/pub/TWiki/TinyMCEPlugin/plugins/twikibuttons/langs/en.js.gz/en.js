tinyMCE.addI18n('en.twikibuttons', {
    tt_desc: "Typewriter text",
    colour_desc: "Font color",
    attach_desc: "Manage Attachments",
    indent_desc: "Indent more",
    exdent_desc: "Indent less",
    hide_desc: "Edit TWiki markup"
});
